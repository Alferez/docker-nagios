Default User: nagiosadmin
Default Pass: 1234

